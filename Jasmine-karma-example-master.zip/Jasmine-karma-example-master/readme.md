##Running the sample code
The sample code doesn't have UI. It has a set of files with some AngularJS code and corresponding test files.

To run the sample, open a command prompt and execute the following commands:

 -  npm install (to install karma package)
 -  npm install -g grunt-cli (to install grunt cli globally)
 -  npm install -g karma-cli (to install karma cli globally)
 -  bower install (to install front-end packages)
 -  grunt (to start karma and run tests)
 
Ravi's SitePoint article on Mocking dependencies in AngularJS tests: http://www.sitepoint.com/mocking-dependencies-angularjs-tests/